---
document_id: "doc_ac040c5342f89836822e"
version_id: "ver_ac040c53_4e3bd11e3f93"
title: "Anunț pentru părțile interesate de procesul decizional"
source_url: "https://botanica.md/anunt-pentru-partile-interesate-de-procesul-decizional-585"
retrieved_at: "2026-09-25T17:41:11.508965+00:00"
content_sha256: "4e3bd11e3f931cd28422d92e2e71093fce5a5ed81557a0a3465205bbac66eda1"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

# Anunț pentru părțile interesate de procesul decizional

Pretura sectorului Botanica, în calitatea sa de ***subdiviziune-autor din cadrul autorităţii publice*** anunță elaborarea ***Listei organizaţiilor neguvernamentale pe domenii de activitate interesate în procesul decizional,*** în **scopul informării prioritare** și **facilitării accesului părţilor interesate la informaţia privind procesul decizional**.

Astfel, în conformitate cu prevederile art. 3 alin. (1), (2) lit. g și (4), art. 8 lit. c din Legea nr. 239/2008 privind transparenţa în procesul decizional și pct. 7, 9, 10, 12 din Regulamentul cu privire la procedurile de consultare publică cu societatea civilă în procesul decizional, aprobat prin Hotărârea Guvernului Republicii Moldova nr. 967 din 09.08.2016, ne adresăm ***părților interesate care doresc să fie informate prioritar despre procesul decizional inițiat de Pretura sectorului Botanica*** să vină cu o solitare.

Informăm, că Lista părților interesate estre actualizată semestrial, în conformitate cu pct. 7 din Regulament.

**Pentru includerea în Lista părților interesate** (numele şi prenumele cetăţenilor, denumirile asociaţiilor constituite în corespundere cu legea, altor părţi interesate, informaţia de contact a acestora) solicitarea urmează a fi transmisă în scris Preturii de sector. Persoana responsabilă de coordonarea procesului de consultare publică va pregăti o listă generală a părţilor interesate, care vor fi informate prioritar despre procesul decizional prin intermediul poştei electronice ori prin expedierea scrisorilor la adresa părţilor interesate sau cea indicată de solicitant.

Respectiv, în conformitate cu pct. 7 și 9 din Regulament este necesară ca partea interesată să solicite  în scris informarea. Vă rugăm să anexați la solicitare informația (cetățeni) despre solicitant: numele, prenumele, date de contact, domiciliu, poșta electronică. Pentru persoane juridice: denumirile asociaţiilor constituite în corespundere cu Legea, numele, prenumele președintelui, informaţia de contact (telefonul, e-mail), adresa  și **domeniile pentru care manifestă interes**.**Termenul limită de prezentare a informației / cererii - 31 ianuarie 2023.**

Potrivit Codului administrativ nr. 116 din 19.07.2018 cererea poate fi depusă în scris ori expediate prin poștă (str. Teilor, 10, MD-2043,  municipiul Chişinău, Republica Moldova, Pretura sectorului Botanica), fie trimise în formă electronică ([pretura.botanica@pmc.md](mailto:pretura.botanica@pmc.md)), ***obligatoriu însoțită de semnătura electronică***.

Lista părților interesate va fi generalizată și publicată pe pagina oficială a preturii.
