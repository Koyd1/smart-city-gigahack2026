---
document_id: "doc_87a5b55fc5dec83bb32f"
version_id: "ver_87a5b55f_2705e323b3e3"
title: "În sectorul Botanica s-a desfășurat prima rundă de discuții publice"
source_url: "https://botanica.md/in-sectorul-botanica-s-a-desfasurat-prima-runda-de-discutii-publice"
retrieved_at: "2026-09-25T18:10:00+00:00"
content_sha256: "2705e323b3e33ad2dbb48a3a3b8aaa2541297dbdc81fc2c6c8aadeb680ca4f0e"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

# În sectorul Botanica s-a desfășurat prima rundă de discuții publice

La 02 decembrie 2021, în incinta Preturii sectorului Botanica s-au desfășurat discuții publice referitor la proiectele prioritare pentru anul 2022, care au fost elaborate în concordanță cu multiplele propuneri și sugestii ale locuitorilor sectorului.

La discuțiile publice au fost prezenți Ilie Ceban și Olga Ursu Viceprimarii municipiului Chișinău, consilieri municipali, colaboratori ai direcțiilor municipale, angajați ai serviciilor și direcțiilor din sector, reprezentanți ai ONG-urilor, funcționari din cadrul preturii și societatea civilă.

Astfel, Pretura sectorului Botanica a invitat locuitorii sectorului să se implice direct în procesul de dezbateri, care nu este prima dată, când astfel de proiecte extrem de mari și ambițioase sunt discutate cu publicul larg.

Viceprimarul Olga Ursu, succint, a prezentat audienței proiectul de buget pentru anul viitor pe fiecare domeniu în parte și pentru fiecare sector.

Ulterior, Diana Guba, Pretorul sectorului Botanica, a oferit detalii despre proiectele inițiate și desfășurate în sector, cât și cele ce urmează a fi elaborate și aprobate pentru implementare în anul 2022.

Cei prezenți la dezbateri au salutat schimbările înfăptuite în sectorul Botanica și au venit cu diferite propuneri și obiecții la proiectele ce urmează a fi implementate în vederea soluționării problemelor existente, cât și diversificarea activităților distractive.

În sectorul Botanica întru implementarea proiectelor inițiate, pentru lucrările de amenajare a spațiilor verzi și reabilitare a obiectivelor de infrastructură vor fi alocați în anul 2022 circa 33 de mln. de lei.
