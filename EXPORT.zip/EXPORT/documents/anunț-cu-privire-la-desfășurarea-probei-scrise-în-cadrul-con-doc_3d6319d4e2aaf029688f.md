---
document_id: "doc_3d6319d4e2aaf029688f"
version_id: "ver_3d6319d4_e35c20f65359"
title: "Anunț cu privire la desfășurarea probei scrise în cadrul concursului privind ocuparea funcțiilor publice vacante (11.10.2023)"
source_url: "https://botanica.md/anunt-cu-privire-la-desfasurarea-probei-scrise-in-cadrul-concursului-privind-ocuparea-functiilor-publice-vacante-11102023"
retrieved_at: "2026-09-25T17:40:05.706146+00:00"
content_sha256: "e35c20f65359ecd430dafb19042a270c9e1be91744a7efcdb577a44d92e6cedb"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

# Anunț cu privire la desfășurarea probei scrise în cadrul concursului privind ocuparea funcțiilor publice vacante (11.10.2023)

În urma analizei dosarelor depuse pentru ocuparea funcției publice, în conformitate cu prevederile Regulamentului cu privire la ocuparea funcției publice vacante prin concurs aprobat prin Hotărârea Guvernului nr. 201 din 11 martie 2009, Pretura sectorului Botanica anunță desfășurarea probei scrise în incinta Preturii, biroul 604, la data de 13.10.2023, ora 10:00.

**Au fost admiși la proba scrisă a concursului pentru ocuparea funcției publice vacante de specialist principal, Secția cultură, tineret și sport:**

**- Atamaniuc Victoria;**

**- Cernat Dan.**
