---
document_id: "doc_4900886ed05268a19e54"
version_id: "ver_4900886e_19737abf7b40"
title: "Învățământ"
source_url: "https://botanica.md/institutiile-de-invatamant"
retrieved_at: "2026-09-25T17:51:08.542014+00:00"
content_sha256: "19737abf7b40e2dfd076131547b36999d466eaa31a65523f53475597e97e3cdc"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

# Învățământ

## Instituțiile de învățământ

Instituțiile de învățământ preșcolar și preuniversitar din sector

| Nr. d/o | Denumirea întreprinderii, organizaţiei, instituţiei | Numele, prenumele conducătorului, locţiitorului | Telefon de serviciu |
|  |  |  |  |
| 1 | Instituția Publică Liceul teoretic ,,Alexandru cel Bun" | Zavate Valeriu | dir. 41-31-95; |
|  | or. Singera, str. 31 August, 35, MD-2091 |  | a. 41-32-32; |
|  |  |  |  |
| 2 | Instituția Publică Liceul teoretic ,,Grigore Vieru" | dir. int. Eftode Natalia | dir./fax. 38-12-80; |
|  | com. Băcioi, str. Independenţei, 52, MD-2047 |  | a. 38-32-92; |
|  |  |  |  |
| 3 | Instituția Publică Liceul teoretic "Tudor Vladimirescu" | Fusa Zinaida | dir. 55-61-40; |
|  | str. Paiului, 17, MD-2002 |  | a. 55-10-49; |
|  |  |  |  |
| 4 | Instituția Publică Liceul teoretic "Petru Movilă" | Bogoeva Elena | dir. 55-99-01; |
|  | str. Botanica Veche, 11"a", MD-2032 |  | a. 52-83-53; |
|  |  |  |  |
| 5 | Instituția Publică Liceul teoretic "Liviu Rebreanu" | Izvoreanu Larisa | dir.77-89-18; |
|  | str. Hristo Botev, 9/2, MD-2043 |  | a.76-17-77; |
|  |  |  |  |
| 6 | Instituția Publică Liceul teoretic "Traian" | Gogu Tatiana | a. 66-14-01; |
|  | bd. Cuza Vodă, 36, MD-2060 |  | cont. fax. 56-44-99; |
|  |  |  |  |
| 7 | Instituția Publică Şcoala-grădiniţa "Pas cu pas" nr.152 | Lungu Valentina | dir. 52-30-82; |
|  | bd. Decebal, 91-a, MD-2038 |  | a. 52-87-23; |
|  |  |  |  |
| 8 | Liceul teoretic "Mihai Eminescu" | Dan Mihai | 55-30-96; 55-60-53; |
|  | str. Varşoviei, 2, 2060 |  |  |
|  |  |  |  |
| 9 | Liceul teoretic "Iulia Haşdeu" | Goncear Eleonora | a. 55-73-68; |
|  | str. Titulescu, 18, MD-2032 |  | 55-13-30; |
|  |  |  |  |
| 10 | Liceul teoretic ,,Iulia Hajdeu" (blocul claselor primare) | Goncear Eleonora | a. 55-73-68 |
|  | str. Pandurilor, 66, MD-2032 |  | paza. 55-01-98 |
|  |  |  |  |
| 11 | Liceul teoretic "Bogdan Petriceicu Haşdeu" | Mihailescu Svetlana | dir. 55-04-97; |
|  | str. Zelinski, 34, MD-2038 |  | a. 52-10-07; |
|  |  |  |  |
| 12 | Liceul teoretic "Mihai Grecu" | Glotova Svetlana | dir. 76-18-49; |
|  | str. Valea Crucii, 4/2, MD-2060 |  | a. 76-86-61; |
|  |  |  |  |
| 13 | Liceul teoretic "Nicolae Iorga" | dir. int. Grozav Natalia | dir. 77-46-92; |
|  | str. Valea Crucii, 4/1, MD-2060 |  | a. 76-66-53; |
|  |  |  |  |
| 14 | Liceul teoretic seral nr. 2 | Ivanova Nina | dir. 76-34-36; |
|  | bd. Traian, 11/2, MD-2060 |  | 76-16-58; |
|  |  |  |  |
| 15 | Gimnaziul "Nicolae Costin " | Guzun Silvia | dir. 55-90-22; |
|  | str. Hanul Morii, 42 MD 2023 |  | a. 55-01-17; |
|  |  |  |  |
| 16 | Şcoala specială pentru copii hipoacuzici cu surditate tardivă nr.12 | Rusu Nina | dir. 66-19-81, dir.adj. 66-19-91 |
|  | bd. Cuza Vodă, 34, MD-2060 |  | fax. 66-18-81 |
|  |  |  |  |
| 17 | Liceul Teoretic cu profil sportiv "Gloria" | Pădureţ Nicolae | dir. 56-61-62; |
|  | str. Teilor, 7, MD-2043 |  | a. 77-78-30; |
|  |  |  |  |
| 18 | Gimnaziul "Galata" | Macarenco Nicolae | dir. 52-54-86; |
|  | bd. Dacia, 75, MD-2060 |  | a. 52-44-90; |
|  |  |  |  |

| Nr. d/o | Denumirea întreprinderii, organizaţiei, instituţiei | Numele, prenumele conducătorului, locţiitorului | Telefon de serviciu |
| 19 | Liceul teoretic ,,Pro-Succes" | dir. int. Cristea Nadia | a. dir. 35-20-67 |
|  | str. Aşhabad, 129, MD-2018 |  | dir. adj. 55-15-22 |
|  |  |  |  |
| 20 | Liceul teoretic cu profil de arte "Elena Alistar" | Ocinschi Maria | a./fax. 55-02-15; |
|  | bd. Decebal, 74, MD-2038 |  | dir.adj. 55-70-08; |
|  |  |  |  |
| 21 | Gimnaziul nr. 31 | Pînzaru Nina | dir./fax. 55-73-09 |
|  | şos. Munceşti, 400, MD-2018 |  | a. 55-30-93 |
|  |  |  |  |
| 22 | Gimnaziul nr. 49 | dir. int. Creţu Ludmila | dir. 52-41-13; |
|  | şos. Munceşti, 780, MD-2029 |  | dir. adj. 24-93-00 |
|  |  |  |  |
| 23 | Liceul teoretic "Mircea cel Bătrân" | Teşcu Mihai | dir. 55-52-33; |
|  | str. Sarmisegetuza, 39, MD-2032 |  | a. 55-52-12; |
|  |  |  |  |
| 24 | Şcoala - grădiniţă nr. 90 | dir. int. Rusu Mariana | a. dir. 76-54-88; |
|  | bd. Dacia, 52, MD-2060 |  |  |
|  |  |  |  |
| 25 | Gimnaziul "Decebal" | Donţu Iurie | dir./fax. 76-58-33; |
|  | str. Grenoble, 191, MD-2019 |  | dir. adj. 56-61-00; |
|  |  |  |  |
| 26 | Şcoala primară nr.101 | dir. int. Secrieru Lilia | a./dir. 38-32-80; |
|  | com. Bacioi, str. Sfîntul Arhanghel Mihail, 10, MD-2047 |  | fax. 38-29-49; |
|  |  |  |  |
| 27 | Liceul teoretic ,,Grigore Vieru" | dir. int. Eftode Natalia | dir./fax. 38-12-80; |
|  | com. Băcioi, str. Independenţei, 52, MD-2047 |  | a. 38-32-92; |
|  |  |  |  |
| 28 | Gimnaziul nr.102 | Babalici Eudochia | 42-34-46; |
|  | com. Bacioi, s. Brăila, str. Renaşterii, 14, MD-2047 |  | a. 42-33-29; |
|  |  |  |  |
| 29 | Gimnaziul nr. 67 | Iurco Valentina | dir./fax. 38-00-19; |
|  | mun. Chișinău, s. Revaca, str. Stefan cel Mare, 17, MD-2091 |  |  |
|  |  |  |  |
| 30 | Gimnaziul nr. 68 | Vişnevschi Ana | 25-80-65 |
|  | or. Sîngera, s. Dobrogea |  |  |
|  |  |  |  |
| 31 | Grădiniţă-creşă nr. 40 | Cristofor Maria | dir. 76-28-22; |
|  | bd. Dacia, 24/2, MD-2043 |  |  |
|  |  |  |  |
| 32 | Creşa-grădiniţă nr. 71 | Lutan Galina | a. 66-16-61; |
|  | bd. Dacia, 28/2, MD-2060 |  |  |
|  |  |  |  |
| 33 | Creşă - grădiniţă nr. 106 | Borisovscaia Eugenia | dir. 77-95-00; |
|  | str. Hristo Botev, 19/4, MD-2043 |  |  |
|  |  |  |  |
| 34 | Şcoala-grădiniţă nr. 120 | Slusari Natalia | dir. 55-02-19; |
|  | str. Independenţii, 14, MD-2060 |  | a. 76-76-55; |
|  |  |  |  |
| 35 | Şoala-grădiniţă nr. 124 | Furculiţă Angela | dir. 77-95-11; |
|  | bd. Cuza Vodă, 18/4, MD-2060 |  |  |
|  |  |  |  |
| 36 | Creşa-grădiniţă nr.165 | Stratu Aliona | dir. 55-10-08; |
|  | bd. Cuza Vodă, 7/5, MD-2060 |  |  |
|  |  |  |  |
| 37 | Creşa-grădiniţa română nr.168 | Burlac Inna | dir. 76-56-55; |
|  | bd. Cuza Vodă, 29/7, MD-2060 |  |  |
|  |  |  |  |

| Nr. d/o | Denumirea întreprinderii, organizaţiei, instituţiei | Numele, prenumele conducătorului, locţiitorului | Telefon de serviciu |
| 38 | Creşa-grădiniţa română nr. 9 | Chilimar Raisa | dir. 55-13-17 |
|  | str. Titulescu, 10A, MD-2032 |  |  |
|  |  |  |  |
| 39 | Creşa-grădiniţa nr.17 | Moşanu Elena | dir. 55-73-79; |
|  | str. Zelinski, 33/3, MD-2038 |  |  |
|  |  |  |  |
| 40 | Creşa-grădiniţa nr. 35 | Compeinici Maria | 55-70-09; |
|  | str. Pandurilor, 4, MD-2032 |  | 55-40-86; |
|  |  |  |  |
| 41 | Creşa-grădiniţa nr. 44 | Castraveţ Radusea | 55-83-15 |
|  | str. Dante Aligheri, 7, MD-2018 |  |  |
|  |  |  |  |
| 42 | Creşa-grădiniţa nr. 49 | Clim Eugenia | 77-34-41 |
|  | str. Independenţii, 32/2, MD-2060 |  |  |
|  |  |  |  |
| 43 | Grădiniţa rusă nr. 77 | Mitieva Valentina | 55-04-84 |
|  | str. Zelinski, 32/7, MD-2038 |  |  |
|  |  |  |  |
| 44 | Creşa-grădiniţa nr. 89 | Andriuţă Irina | 55-55-60 |
|  | str. Zelinski, 26/3, MD-2038 |  |  |
|  |  |  |  |
| 45 | Creşa-grădiniţa română nr. 91 | Rotaru Tatiana | 55-15-72 |
|  | str. Zelinski, 36/5, MD-2038 |  |  |
|  |  |  |  |
| 46 | Creşa-grădiniţa română nr. 96 | Ciotu Tatiana | 55-42-01 |
|  | str. Zelinski, 12/2, MD-2038 |  |  |
|  |  |  |  |
| 47 | Creşa-grădiniţa mixtă nr. 98 | Sacara Liudmila | 55-04-04 |
|  | str. Cetatea Albă, 152, MD-2018 |  |  |
|  |  |  |  |
| 48 | Creşa-grădiniţa rusă nr. 99 | Orlov Maria | 55-43-28 |
|  | str. Căuşeni, 2A, MD-2018 |  |  |
|  |  |  |  |
| 49 | Creşa-grădiniţa rusă nr.103 | Gherasimovici Anastasia | 52-40-39 |
|  | str. Munceşti, 798, MD-2029 |  |  |
|  |  |  |  |
| 50 | Creşa-grădiniţa română nr.104 | Dembiţchi Valentina | 55-55-21 |
|  | str. Munceşti, 402, MD-2018 |  |  |
|  |  |  |  |
| 51 | Creşă-grădiniţa rusă nr.112 | Ropot Galina | 55-60-11 |
|  | str. Brîncuşi, 133, MD-2060 |  |  |
|  |  |  |  |
| 52 | Grădiniţa rusă nr.122 | Capaţina Ana | 66-15-51 |
|  | str. Independenţii, 9/2, MD-2060 |  |  |
|  |  |  |  |
| 53 | Grădiniţa mixtă nr. 123 | Gabroveanu Ala | 52-49-42 |
|  | str. Aeroport, MD-2060 |  |  |
|  |  |  |  |
| 54 | Grădiniţa română nr. 139 | Colun Angela | 55-61-36 |
|  | str. Praga, 82, MD-2060 |  | 63-74-11 |
|  |  |  |  |
| 55 | Grădiniţa română nr. 141 | Zavadschii Lilia | 52-34-17 |
|  | str. Sarmisegetuza, 39/3, MD-2018 |  | 52-34-18 |
|  |  |  |  |
| 56 | Creşa-grădiniţa română nr.142 | Vornicescu Ecaterina | 76-66-77 |
|  | bd. Traian, 19/1, MD-2060 |  |  |
|  |  |  |  |

| Nr. d/o | Denumirea întreprinderii, organizaţiei, instituţiei | Numele, prenumele conducătorului, locţiitorului | Telefon de serviciu |
| 57 | Creşa-grădiniţa rusă nr. 151 | Gavriluc Victoria | 76-05-91 |
|  | str. Grenoble, 207, MD-2060 |  |  |
|  |  |  |  |
| 58 | Creşa-grădiniţa română nr. 153 | Andronic Silvia | 76-69-22 |
|  | bd. Dacia, 36/2, MD-2060 |  |  |
|  |  |  |  |
| 59 | Creşa-grădiniţa română nr. 180 | Şhaya Diana | 77-54-55, 77-48-26 |
|  | bd. Dacia, 53/3, MD-2060 |  |  |
|  |  |  |  |
| 60 | Creşa-grădiniţa română nr.181 | Vicol Daniela | 77-54-44 |
|  | bd. Dacia, 53/2, MD-2060 |  | 77-54-41 |
|  |  |  |  |
| 61 | Creşa-grădiniţa mixtă nr. 182 | Cogut Tatiana | 76-55-93 |
|  | bd. Cuza Vodă, 39/3, MD-2060 |  |  |
|  |  |  |  |
| 62 | Creşa-grădiniţa română nr. 216 | Popov Ana | 53-09-27, 55-72-16 |
|  | bd. Decebal, 82/3, MD-2038 |  |  |
|  |  |  |  |
| 63 | Grădiniţa română nr. 202 | Viţu Eugenia | 41-23-23 |
|  | or. Singera, MD-2091 |  |  |
|  |  |  |  |
| 64 | Grădiniţa română nr. 205 | Zmeu Olga | 38-01-57 |
|  | or. Sîngera, s. Revaca, MD-2029 |  |  |
|  |  |  |  |
| 65 | Grădiniţa nr. 214 | Colin Lidia | dir.25-80-66 |
|  | or. Sîngera, s. Dobrogea, str. I. Creangă, 11/2, MD-2086 |  |  |
|  |  |  |  |
| 66 | Grădiniţa română nr.101, nr. 171 | Popovici Elena | 38-29-63 |
|  | com. Bacioi, MD-2047 |  | 38-29-46 |
|  |  |  |  |
| 67 | Creşa-grădiniţa nr. 176 | Laşcu Tatiana | 38-11-66 |
|  | com. Băcioi, str. Doina, 76 |  |  |
|  |  |  |  |
| 68 | Creşa-grădiniţa română nr.45 | Garabajiu Ecaterina | 42-32-83 |
|  | com. Bacioi, s. Brăila, MD-2047 |  |  |
|  |  |  |  |
| 69 | Centrul de Creaţie al Copiilor "Luceafărul" | Guţul Raisa | dir.77-89-29 |
|  | str. Valea Crucii, 2, MD-2062 |  | 77-04-41 |
|  |  |  | 56-39-55 |
| 70 | Tabara de odihnă pentru copii "Poieniţa veselă" | Patic Ion | 76-76-88 |
|  | s. Dânceni |  |  |
|  |  |  |  |
| 71 | Tabăra de odihnă "Alunelul" | Patic Ion | 0-268-21909 |
|  | s. Bardar |  |  |
|  |  |  |  |
| 72 | Bazin de înot pentru copii | Caluian Tatiana | 77-97-45 |
|  | str. Valea Crucii, 4/3, MD-2060 |  |  |
|  |  |  |  |
| 73 | Liceul teoretic "Dimitrie Cantemir" | Aproţcaia Tamara | dir./fax. 77-25-44 |
|  | bd. Dacia, 28/3 |  | 76-26-77 |
|  |  |  | 77-25-14 |
| 74 | Şcoala primară, filială a liceului "Dimitrie Cantemir" | Aproţcaia Tamara | 76-67-22 |
|  | bd. Dacia, 38/2, MD-2060 |  |  |
|  |  |  |  |
| 75 | Liceul teoretic "Vasile Alecsandri" | Vacarciuc Daniela | 35-48-22 |
|  | str. Mazililor, 34 "A", MD-2060 |  | 35-47-61 |

| Nr. d/o | Denumirea întreprinderii, organizaţiei, instituţiei | Numele, prenumele conducătorului, locţiitorului | Telefon de serviciu |
|  |  |  |  |
| 76 | Liceul Teatral Orăşenesc | Harmelin Iurie | 55-10-42 |
|  | bd. Cuza Vodă, 19/3, MD-2060 |  | 52-84-51 |
|  |  |  |  |
| 77 | Liceul teoretic "Rambam" | Şcolnic Sofia | 77-59-94 |
|  | str. Independenţei, 5/2, MD-2043 |  |  |
|  |  |  |  |
| 78 | Centrul Orăşenesc al Tinerilor Naturalişti | Ciobanu Vera (interimar) | dir.56-45-20 |
|  | bd. Traian, 3, MD-2060 |  | 76-35-66 |
