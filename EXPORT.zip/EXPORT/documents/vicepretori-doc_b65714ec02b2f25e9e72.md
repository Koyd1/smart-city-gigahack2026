---
document_id: "doc_b65714ec02b2f25e9e72"
version_id: "ver_b65714ec_cf54879b9b7e"
title: "Vicepretori"
source_url: "https://botanica.md/vicepretori"
retrieved_at: "2026-09-25T17:51:02.055683+00:00"
content_sha256: "cf54879b9b7e8f21a3f1a18821fb19b0b9859510e5e7ca6be57954be7e0b1539"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

**Vicepretor - Vladislav TABAC**

Este responsabil de dezvoltarea şi funcţionarea sistemului edilitar-gospodăresc al sectorului, organizarea lucrărilor de reparaţie curentă şi capitală a spaţiului locativ şi reţelelor inginereşti interioare, evidenţa şi exploatarea fondului locativ, salubrizarea şi amenajarea teritoriului sectorului, exploatarea spaţiilor verzi şi evacuarea deşeurilor, exercitîndu-şi atribuţiile în limita competenţelor acordate preturilor de sector. Competenţele vicepretorului: Supravegherea și coordonarea lucrărilor de reparație curentă și capitală a fondului locativ și a rețelelor inginerești interioare din sector Organizarea și monitorizarea procesului de exploatare a fondului locativ. Monitorizarea și coordonarea lucrărilor de amenajare şi salubrizare a teritoriului. Conlucrarea cu serviciile abilitate în vederea dezvoltării și întreținerii sistemului edilitar-gospodăresc din sector Coordonarea activităţii prestatorilor de servicii publice din sector. Patronează activitatea: Secției locativ-comunale, Secției urbanism și arhitectură.

Programul de audiențe:

Vicepretorul sectorului Botanica efectuează audiența cetățenilor în fiecare zi de luni, bir. 508, cu începere de la ora 15.00. Înscrierea cetățenilor în audiență la vicepretor se poate face în anticameră, verbal sau în scris, între orele 8.00 - 12.00; 13.00 - 17.00. telefon de contact: (022) 769581

 **Vicepretor - Carolina NEDELEA.**

Este responsabil de dezvoltarea sferei social-economice a sectorului, prestarea serviciilor de comerţ şi alimentaţie publică, de activitatea pieţelor din sector, de protecţia socială a populaţiei, exercitîndu-şi atribuţiile în limita împuternicirilor acordate preturilor de sector. Competenţele vicepretorului: Coordonarea activităților socio-culturale și economice din sector. Coordonarea prestării serviciilor de comerț și alimentație publica, precum și activități pieților comerciale din sector. Promovarea respectării relațiilor interetnice, dezvoltarea și promovarea valorilor culturale în sector. Promovarea politicilor statului în domeniu învățămîntului tineretului sportului și protecției sociale a populației în sector. Organizarea și coordonarea acțiunilor în vederea combaterii comerțului ilicit. Patronează activitatea: Secţiei social-econimice, Secţiei cultură, tineret şi sport.

Programul de audiențe:

Vicepretorul sectorului Botanica efectuează audiența cetățenilor în fiecare zi de luni, cu începere de la ora 15.00. Înscrierea cetățenilor în audiență la vicepretor se poate face în anticameră, verbal sau în scris, între orele 8.00 - 12.00; 13.00 - 17.00. telefon de contact: (022) 769444
