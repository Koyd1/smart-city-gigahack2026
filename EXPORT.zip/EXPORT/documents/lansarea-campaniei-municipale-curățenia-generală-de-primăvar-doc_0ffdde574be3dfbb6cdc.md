---
document_id: "doc_0ffdde574be3dfbb6cdc"
version_id: "ver_0ffdde57_df72ca674987"
title: "Lansarea campaniei municipale „Curățenia generală de primăvară” în sectorul Botanica"
source_url: "https://botanica.md/lansarea-campaniei-municipale-curatenia-generala-de-primavara-in-sectorul-botanica"
retrieved_at: "2026-09-25T18:10:00+00:00"
content_sha256: "df72ca67498786b7cbef9502e49b56455be76902b84ea86809933ced2b4e209a"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

În conformitate cu prevederile dispoziției pretorului sectorului Botanica nr. 65 din 17.03.2021 a fost aprobat Planul privind salubrizarea și amenajarea sectorului Botanica în perioada 01.03.2021-30.04.2021 în cadrul campaniei municipale „Curățenia generală de primăvară”.

Planul de acțiuni prevede antrenarea la acțiunile de amenajare și salubrizare din sector a ÎMGFL nr. 1-7, APLP, ACC, CCL, căminele, blocurile departamentale, casele locative cu capital privat, asociațiile obștești, agenții economici din sector, locuitorii sectorului.

De asemenea urmează ca agenții constatatori din cadrul Preturii sectorului Botanica de comun cu persoanele desemnate de către Direcția generală locativ-comunală și amenajare să efectueze acțiuni de verificare a stării sanitare și întocmire după caz a procese-verbale cu privire la contravenție, în baza art. 154, art. 181 din Codul Contravențional al Republicii Moldova, pentru neasigurarea curățeniei și încălcarea regulilor de gestionare a deșeurilor de către gestionarii fondului locativ indiferent de forma de proprietate, agenții economici, proprietarii caselor particulare și vor înainta procesele-verbale întocmite spre examinare Comisiei administrative.

De asemenea au fost trasate sarcini pentru Î.M. Asociația de Gospodărire a Spațiilor Verzi sectorul Botanica, Î.M. Regia „Autosalubritate” sectorul Botanica, Direcția Educație, Tineret şi Sport Botanica, Asociația Medicală Teritorială Botanica și Inspectoratul de Poliție Botanica.
