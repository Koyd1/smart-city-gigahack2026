---
document_id: "doc_77d161803a779a57396e"
version_id: "ver_77d16180_9bccfbdc5f3d"
title: "Restricționarea accesului vizitatorilor în incinta Preturii sectorului Botanica"
source_url: "https://botanica.md/restrictionarea-accesului-vizitatorilor-in-incinta-preturii-sectorului-botanica"
retrieved_at: "2026-09-25T17:48:40.187175+00:00"
content_sha256: "9bccfbdc5f3d8fd155f676db1e5de0a87376da7336511e995d5eda00acec2b2c"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

# Restricționarea accesului vizitatorilor în incinta Preturii sectorului Botanica

În scopul executării pct. 1 din Dispoziția Primarului General al municipiului Chișinău nr. 203-dc din 16.03.2021 „Cu privire la activitatea angajaților din subdiviziunile structurale ale autorităților publice locale din municipiul Chișinău pentru zilele de 16-31 martie 2021”,  și prevenirii răspândirii infecției COVID-19 pe teritoriul pe teritoriul municipiului Chișinău, a fost emisă Dispoziția nr. 66 din 18.03.2021, care instituie un program special de activitate a Preturii Botanica din data de **16 - 31 martie 2021, inclusiv.**

Astfel, este **restricționat accesul tuturor persoanelor** în incinta Preturii sectorului Botanica, în așa fel, încât depunerea cererilor, petițiilor și eliberarea actelor solicitate se va efectua prin adresa de e-mail: [botanica@pmc.md](mailto:pretura.botanica@pmc.md) sau aplicația „Petiții Online” de pe pagina oficială a preturii [www.botanica.md](http://www.botanica.md) și prin adresa poștală: mun. Chișinău, str. Teilor, 10.

De asemenea conducătorilor instituțiilor aflate în chirie vor asigura regimul special de muncă, prin restricționarea **accesului tuturor persoanelor** cu asigurarea preluării petițiilor de la recepția Preturii.
