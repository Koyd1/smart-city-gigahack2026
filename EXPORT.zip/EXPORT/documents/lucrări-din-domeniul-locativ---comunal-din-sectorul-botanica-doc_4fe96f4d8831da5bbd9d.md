---
document_id: "doc_4fe96f4d8831da5bbd9d"
version_id: "ver_4fe96f4d_d87863bb0b7b"
title: "Lucrări din domeniul locativ - comunal din sectorul Botanica (29.03 - 02.04.2021)"
source_url: "https://botanica.md/lucrari-din-domeniul-locativ-comunal-din-sectorul-botanica-2903-02042021"
retrieved_at: "2026-09-25T18:10:00+00:00"
content_sha256: "d87863bb0b7bcf42be3e42a1251be1cb60679132d01a49dc5ef78b7b678557ff"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

# Lucrări din domeniul locativ - comunal din sectorul Botanica (29.03 - 02.04.2021)

Pe parcursul săptămânii curente, de către serviciile specializate din sector, au fost efectuate următoarele lucrări:

| **Nr.**  **d/o** | **Denumirea lucrărilor** | **Un./m** | **Perioada** **26.03.2021-02.04.2021**  |
| 1. | Au participat lucrători pe salubrizare | pers. | 250 zilnic |
| 2. | Au participat lucrători la dezinfectare | pers. | 50 |
| 3. | A lucrat tehnică la salubrizare | un. | 47 ( 17 – ÎMSL, 10 – AGSV, 20- ÎMGFL 1-7) |
| 4. | S-au efectuat rute | un. | 77 (14 - ÎMSL, 25 - AGSV, 38 - ÎMGFL 1-7) |
| 5. | Staţii salubrizate | un. | 71 |
| 6. | Terenuri de acumulare a deşeurilor menajere deszăpezite/salubrizate | un. | 192 |
| 7. | Camere de acumulare a deşeurilor menajere salubrizate | un. | 101 |
| 8. | Treceri de pietoni – manual | un. | 145 |
| 9. | Treceri subterane | un. | 6 |
| 10. | Terenuri de joacă fitness, sport - dezinfectate | un | 170 |
| 11. | Procese - Verbale întocmite, art. 181 CC | un. | 16 |

1.  **ÎMSL Botanica** :17 unități de transport și 14 rute. S–au făcut lucrări de salubrizare şi evacuare a gunoiului menajer din pasajele subterane din bd. Decebal - bd. Dacia - bd. Traian şi din bd. Dacia - str. Teilor. La fel s-au realizat lucrări de salubrizare și evacuare a crengilor, frunzișului și deșeurilor menajere  și de construcție din str. Calea Basarabiei, bd. Dacia, 60/4, șos. Muncești, 772, 792/2, str. Valea Crucii, str. Grenoble, 203, 205. S-au evacuat deşeuri menajere de pe platoul de acumulare a deșeurilor din str. Cetatea Alba, 20, și s-a salubrizat teritoriul adiacent. S-au efectuat lucrări de salubrizare si evacuare a crengilor, frunzișului, deșeurilor menajere de pe teritoriul adiacent Liceului ”Elitex” din bd. Dacia, 53/2. S-a realizat evacuarea deșeurilor de construcție în urma demontării și evacuării gheretei din Cuza-Vodă, 30/1 și gardurilor din str. Independenței, 21/1.
2.  **EXDRUP*O:*** *Salubrizarea manuală:* Grădina Botanică – 1 cursă, Drumul Băcioii Noi – 3 curse, estacada Sângera – 14 curse. *Salubrizarea mecanizată* : bd. Dacia, Viaduct, bd. Decebal, str. Independenții, str. Teilor, str. Hristo Botev, str. Burebista. str. Grădina Botanica, str. Valea Crucii, str. Grenoble,  bd. Cuza Vodă, bd. Traian, bd. Dacia – Aeroport – Sângera, șos. Muncești, str. Băcioii Noi*. Salubrizarea mecanizată  în noapte* : spălarea părții carosabile din bd. Dacia, Viaduct, bd. Decebal, str. Hristo Botev, str. Independenții, str. Teilor, str. Burebista, str. Grădina Botanică, bd. Cuza Vodă, bd. Traian, str. Zelinski.  S-au efectuat lucrări de evacuare a gunoiului din str. Praga, 82, - 7 curse, str. Varșovia, 2, - 5 curse. La fel pe str. Praga, 82, s-a făcut montarea zidării – 57 buc, s-a amenajat pietriș - 5, 8 t și s-au montat borduri – 43 buc. Pe str. Varșovia, 2, s-au făcut lucrări de desfacere borduri - 100 buc. și desfacere zidării – 100 buc. S-a realizat curățire/profilare acostamentului pe estacada Sângera – 8 curse.
3.  **A****GSV Botanica** : au activat – 10 unități de transport cu evacuarea a 25 rute de deșeuri menajere, crengi, frunze. S-au efectuat lucrări de salubrizare a teritoriului – 39 ha. S-au greblat manual 1,7 ha.*Gunoişti* neautorizate*lichidate* – 12 unități.
4.  **ÎMGFL nr. 1-7:** au activat – 20 unități de transport cu evacuarea a 38 rute de deșeuri de construcții, menajere și a frunzișului. ÎMGFL nr.1-7 au efectuat lucrări de salubrizare a teritoriului adiacent a blocurilor locative și a platformelor de gunoi din străzile: bd. Decebal, 82, 82/1, 82/2, 84, bd. Dacia, 2, 4, 5, 6, 12, 38, 38/3, 50, str. Zelinski, 4, 5/2, 5/7, 12, 13/4, 32/2, 35/4, 34/5, str. Burebista, 66/4, str. Sarmizegetusa, 37/4, 96/2, str. Busuiocești, 18, str. Cetatea Chilia, 73, str. Cetatea Alba, 97, str. Grădescu 5, șos. Muncești, 238, 240, 404, 406, 794, 798, 800/ 2, str. Grădina Botanica, 12, str. Aeroport, 11, 12, str. Dimineții, 3, 51A, str. Titulescu, 1, 39, 53/3, 55, str. Pandurilor, 2, 16, 18, 22, bd. Traian, 1/1, 6/1, 7, 10, 11, 14/4, 18,  19/1, 23/1, 23/2, str. Independenței, 2/3, 6/3, 7/2, 10/5, 20/1, 24/3, bd. Cuza Voda,  15/1, 25/6, 34, 35/2, 36, 38, 38/2, 39.
