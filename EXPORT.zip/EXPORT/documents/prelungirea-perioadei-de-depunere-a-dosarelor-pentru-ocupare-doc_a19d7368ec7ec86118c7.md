---
document_id: "doc_a19d7368ec7ec86118c7"
version_id: "ver_a19d7368_5361b9f2c6cf"
title: "Prelungirea perioadei de depunere a dosarelor pentru ocuparea funcțiilor publice vacante (03.03.2021)"
source_url: "https://botanica.md/prelungirea-perioadei-de-depunere-a-dosarelor-pentru-ocuparea-functiilor-publice-vacante-03.03.2021"
retrieved_at: "2026-09-25T17:49:00.245577+00:00"
content_sha256: "5361b9f2c6cf209d50b381338ec2a05a1a329bab6b1c26bd77152626d36f597f"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

# Prelungirea perioadei de depunere a dosarelor pentru ocuparea funcțiilor publice vacante (03.03.2021)

**Pretura sectorului Botanica anunță** **prelungirea perioadei de depunere a dosarelor pentru ocuparea funcţiilor publice vacante și temporar vacante din cadrul Preturii sectorului Botanica**

 În contextul noilor restricții impuse prin Hotărârea nr. 45 din 15.02.2021 a Comisiei Naționale Extraordinare de Sănătate Publică, prin care a fost extins termenul stării de urgență în sănătate publică și prin Hotărârea nr. 47 din 26.02.2021 a Comisiei Naționale Extraordinare de Sănătate Publică și Hotărârea nr. 32 din 27.02.2021 a Comisiei Extraordinare de Sănătate Publică a municipiului Chișinău prin care se menține perioada extinderii, având în vedere situația epidemiologică precară, sporirea incidenței, creșterea ratei contagiozității, creșterea numărului de teritorii clasificate în cod roșu de alertă, creșterea numărului formelor grave ale bolii, creșterea numărului de decese, sporirea ratei de pozitivitate a testelor la virusul SARS-CoV-2, creșterea numărului de forme asimptomatice, răspândirea comunitară, toate acestea atestă tendințe de agravare a procesului epidemic a infecției cu COVID-19 în Republica Moldova.

Precum și cazuri confirmarea cazurilor de COVID-19 în incinta instituției, Pretura sectorului Botanica anunță prelungirea perioadei de depunere a dosarelor pentru ocuparea funcției publice de specialist principal, Secția locativ-comunală, funcției publice de specialist principal, Secția urbanism și arhitectură, funcției publice temporar vacante de specialist principal, Secția administrație publică locală, cu informarea ulterioară a potențialilor candidați despre stabilirea admiterii dosarelor la concurs, în dependență de evoluția situației pandemice.
