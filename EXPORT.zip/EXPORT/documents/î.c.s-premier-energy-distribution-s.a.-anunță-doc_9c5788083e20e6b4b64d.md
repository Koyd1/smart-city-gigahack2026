---
document_id: "doc_9c5788083e20e6b4b64d"
version_id: "ver_9c578808_bb0e2a4e394b"
title: "Î.C.S „Premier Energy Distribution” S.A. anunță..."
source_url: "https://botanica.md/ics-premier-energy-distribution-sa-anunta"
retrieved_at: "2026-09-25T17:49:57.844431+00:00"
content_sha256: "bb0e2a4e394b4aaf207823bbb96814ead7d8a3fb892731333ea4a3274e36704c"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

# Î.C.S „Premier Energy Distribution” S.A. anunță...

## Pretura BotanicaÎ.C.S „Premier Energy Distribution” S.A. anunță întreruperi programate ale furnizării energiei electrice (20.01.2021) Pentru îmbunătățirea serviciilor prestate clienţilor, Î.C.S Premier Energy Distribution S.A. anunţă că miercuri, 20 ianuarie 2021, vor avea loc lucrări programate de întreținere, renovare și modernizare a rețelelor electrice pe adresele și în intervalele de timp indicate mai jos în sectorul Botanica: • str. Aeroport, 9002, 9999, str. Andrei Tupolev, 1,2, 3, 4,... 5, str. Astronauţilor, 2, 2A, 2/1, 4, 6, str. Aviatorilor, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, str. Cristofor Columb, 1, 3, 5, 7, 9, bd. Dacia, 69, 73, 75, 77, 79, 81, 83, 9999, str. Navigatorilor, 2, 4, str. Otopeni, 2, 4, 6, 8, 10, str. Plopilor, 1, 2/1, 3, 3/2, 3/3, 5, 7, 9, 11, 13, str. Valerii Cicalov, 1, 3, 5, în intervalul de timp între 08:45 - 16:45 pentru lucrări de reparaţie a echipamentului electric. Pentru informații suplimentare contactați Serviciul Suport Clienți al companiei la telefonul 022-43-11-11. Vaata veel

[Pretura Botanica](https://www.facebook.com/preturasectoruluiBotanica/)

Î.C.S „Premier Energy Distribution” S.A. anunță întreruperi programate ale furnizării energiei electrice (20.01.2021)

 Pentru îmbunătățirea serviciilor prestate clienţilor, Î.C.S Premier Energy Distribution S.A. anunţă că miercuri, 20 ianuarie 2021, vor avea loc lucrări programate de întreținere, renovare și modernizare a rețelelor electrice pe adresele și în intervalele de timp indicate mai jos în sectorul Botanica:

 • str. Aeroport, 9002, 9999, str. Andrei Tupolev, 1,2, 3, 4,... 5, str. Astronauţilor, 2, 2A, 2/1, 4, 6, str. Aviatorilor, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, str. Cristofor Columb, 1, 3, 5, 7, 9, bd. Dacia, 69, 73, 75, 77, 79, 81, 83, 9999, str. Navigatorilor, 2, 4, str. Otopeni, 2, 4, 6, 8, 10, str. Plopilor, 1, 2/1, 3, 3/2, 3/3, 5, 7, 9, 11, 13, str. Valerii Cicalov, 1, 3, 5, în intervalul de timp între 08:45 - 16:45 pentru lucrări de reparaţie a echipamentului electric.

 Pentru informații suplimentare contactați Serviciul Suport Clienți al companiei la telefonul 022-43-11-11. [Vaata veel](https://www.facebook.com/preturasectoruluiBotanica/posts/2494388657528907)
