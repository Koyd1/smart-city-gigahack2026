---
document_id: "doc_ac21afa276e585eaa4ac"
version_id: "ver_ac21afa2_d8b51a0e2db9"
title: "Lucrări din domeniul locativ - comunal din sectorul Botanica (22.02-26.02.2021 )"
source_url: "https://botanica.md/lucrari-din-domeniul-locativ-comunal-din-sectorul-botanica-2202-26022021"
retrieved_at: "2026-09-25T18:10:00+00:00"
content_sha256: "d8b51a0e2db90d34a1a2194aa0f2e905cbaf3d208dbb9627efeba693a611ba84"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

# Lucrări din domeniul locativ - comunal din sectorul Botanica (22.02-26.02.2021 )

Pe parcursul săptămânii curente, de către serviciile specializate din sector, au fost efectuate următoarele lucrări:

| **Nr.**  **d/o** | **Denumirea lucrărilor** | **Un./m** | **Perioada** **19.02.2021-26.02.2021**  |
| 1. | Au participat lucrători pe salubrizare | pers. | 250 zilnic |
| 2. | Au participat lucrători la dezinfectare | pers. | 50 |
| 3. | A lucrat tehnică la salubrizare | un. | 34 ( 15 – ÎMSL,15 – AGSV, 4 - ÎMGFL 1-7) |
| 4. | S-au efectuat rute | un. | 45 (17 - ÎMSL, 18 - AGSV, 10 - ÎMGFL 1-7) |
| 5. | Staţii salubrizate | un. | 71 |
| 6. | Terenuri de acumulare a deşeurilor menajere deszăpezite/salubrizate | un. | 192 |
| 7. | Camere de acumulare a deşeurilor menajere salubrizate | un. | 101 |
| 8. | Treceri de pietoni – manual | un. | 145 |
| 9. | Treceri subterane | un. | 6 |
| 10. | Terenuri de joacă fitness, sport - dezinfectate | un | 170 |
| 11. | Procese - Verbale întocmite, art. 181 CC | un. | 11 |

**1**. **ÎMSL Botanica**: 15 unități de transport și 17 rute. S–au efectuat lucrări de demontare şi evacuare a 5 dispozitive publicitare (6x3) cu termenul de valabilitate a autorizaţiei expirat amplasate pe bd. Decebal, str. L. Dumitriu şi 28 dispozitive publicitare (2x1) din bd. Decebal, bd. Traian, bd. Decebal colţ bd. Dacia. S-a realizat demontarea şi evacuarea complexului din 3 gherete, amplasate pe bd. Traian, 20, colţ str. Grenoble, SA ,,Franzeluţa”. S-au evacuat deşeuri de construcţie în urma demontării şi evacuării complexului de gherete din str. Grenoble, colţ cu bd. Traian. Totodată s-au făcut lucrări de salubrizare şi evacuare a gunoiului menajer şi de construcţie din pasajul subteran din bd. Decebal - bd. Dacia - bd. Traian şi din str. Valea Crucii, a crengilor, frunzişului din str. Independenţei (de la str. Hristo Botev pana la bd. Cuza-Vodă), a deşeurilor de construcţie din curtea blocului locativ din str. Independentei, 12/1 şi evacuarea deşeurilor de construcţie şi a mobilei din 3 apartamente afectate în urma exploziei. La fel s-a salubrizat şi evacuat deşeuri menajere din str. Calea Basarabiei.

**2. EXDRUPO:** *Salubrizarea manuală:* Dacia – 7 curse, bd. Decebal – 3 curse, str. Grădina Botanică - 1cursă, șos. Muncești (nod rutier) – 1 cursă. *Salubrizarea mecanizată:* str. Grădina Botanică, str. Sarmizegetusa, șos. Muncești, str. Trandafirilor. *Salubrizarea pasajelor subterane*: bd. Dacia – str. Teilor, bd. Dacia – bd. Traian. S-au efectuat lucrări de decapare b/a uzat bd. Dacia – Aeroport - 8,6 t. Amenajare pietriș din bd. Dacia – Aeroport - 8,6 t. Lichidarea situației de avariere din str. Burebista - 2 m<sup>2</sup>, bd. Cuza Vodă – 5 m<sup>2</sup>, str. Independenții – 3 m<sup>2</sup>, str. Sarmizegetusa – 2 m<sup>2</sup>, bd. Decebal – 2 m<sup>2</sup>, str. Trandafirilor – 1 m<sup>2</sup>, str. Teilor -3 m<sup>2</sup>, bd. Dacia – 11 m<sup>2</sup>,  str. Grădina Botanică – 6 m<sup>2</sup>, str. Valea Crucii – 10 m<sup>2</sup>, str. Grenoble -1 m<sup>2</sup>, bd. Dacia – Aeroport - 30 m<sup>2</sup>, șos. Muncești (nod rutier) – 8 m<sup>2</sup>, Drumul Băcioi – 2 m<sup>2</sup>. S–au efectuat lucrări de curățire/presărare manual a materialului antiderapant la stațiile de așteptare a  transportului  public din șos. Muncești, Viaduct - 3 000 m<sup>2</sup>, bd. Dacia – 400 m<sup>2</sup> (treceri pietonale).

**3. AGSV Botanica**: au activat – 15 unități de transport cu evacuarea a 18 rute de deșeuri menajere, crengi, frunze. S-au efectuat lucrări de salubrizare a teritoriului – 36 ha. S-a greblat manual 1, 09 ha. S-a maturat mecanizat – 2,1 ha. S-au curățat cu scara arbori decorativi din bd. Dacia – 139 buc. și cu emondor – 131 buc.

**4. ÎMGFL nr. 1-7**: au activat – 4 unități de transport cu evacuarea a 10 rute de deșeuri de construcții, menajere și a frunzișului. ÎMGFL nr.1-7 au efectuat lucrări de salubrizare a teritoriului adiacent a blocurilor locative și a platformelor de gunoi din străzile: str. Independenței, 20/1, 24/1, 24/3, bd. Traian, 19/1, 23/1, 23/2, bd.  Cuza Vodă,  3/2, 15/1, 17/8, 19/1, 19/8, 21/2, 25/5, str. Busuiocești, 18, str. Cetatea Chilia, 73, str. Cetatea Alba, 97, 85A, str. Căușeni, 1**,**  Aeroport, 1-13, bd. Dacia, 60/5.
