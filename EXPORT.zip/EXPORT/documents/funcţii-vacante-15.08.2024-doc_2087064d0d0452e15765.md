---
document_id: "doc_2087064d0d0452e15765"
version_id: "ver_2087064d_a0c0c21818bf"
title: "Funcţii vacante (15.08.2024)"
source_url: "https://botanica.md/721"
retrieved_at: "2026-09-25T17:39:02.194017+00:00"
content_sha256: "a0c0c21818bffb6b1932c6dcf427b14becc3c64a5bc3c1a5843e59d40c10980e"
language: "ro"
category: "district_administration"
document_type: "html"
document_date: null
effective_from: null
effective_to: null
---

În conformitate cu Regulamentul cu privire la ocuparea funcţiei publice prin concurs, aprobat prin Hotărârea Guvernului nr. 201/2009, Pretura sectorului Botanica anunţă concurs pentru ocuparea funcţiilor publice:

- **specialist principal, Secția urbanism și arhitectură - 1 funcție (pe perioadă nedeterminată).**
- **specialist principal, Secția agenți constatatori - 1 funcție (pe perioadă nedeterminată).**
- **specialist principal, Secția locativ-comunală - 1 funcție (pe perioadă nedeterminată).**
- **specialist superior, Secția social - economică - 1 funcție (pe perioadă determinată).**

*Condițiile de participare la concurs, cerințele și bibliografia concursului pot fi găsite și descărcate urmând link-rile de mai jos:*

*[https://cariere.gov.md/ro/job/*/25776#:~:text=Specialist%20principal%20%2C%20Sec%C8%9Bia,05.09.2024%2C%2017%3A00](https://cariere.gov.md/ro/job/*/25776#:~:text=Specialist%20principal%20%2C%20Sec%C8%9Bia,05.09.2024%2C%2017%3A00)*

*[https://cariere.gov.md/ro/job/*/25775#:~:text=Specialist%20principal%20%2C%20Sec%C8%9Bia,05.09.2024%2C%2017%3A00](https://cariere.gov.md/ro/job/*/25775#:~:text=Specialist%20principal%20%2C%20Sec%C8%9Bia,05.09.2024%2C%2017%3A00)*

*[https://cariere.gov.md/ro/job/*/25774#:~:text=Specialist%20principal%20%2C%20Sec%C8%9Bia,05.09.2024%2C%2017%3A00](https://cariere.gov.md/ro/job/*/25774#:~:text=Specialist%20principal%20%2C%20Sec%C8%9Bia,05.09.2024%2C%2017%3A00)*

*[https://cariere.gov.md/ro/job/*/25773#:~:text=Specialist%20superior%20%2C%20Sec%C8%9Bia,05.09.2024%2C%2017%3A00](https://cariere.gov.md/ro/job/*/25773#:~:text=Specialist%20superior%20%2C%20Sec%C8%9Bia,05.09.2024%2C%2017%3A00)*
