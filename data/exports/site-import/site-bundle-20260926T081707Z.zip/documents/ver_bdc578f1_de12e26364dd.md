---
document_id: "doc_bdc578f1c786de0574ef"
version_id: "ver_bdc578f1_de12e26364dd"
title: "83 Licenţă pentru producerea, asamblarea, importul, exportul, reexportul, depozitarea, comercializarea articolelor pirotehnice şi/sau prestarea serviciului „Spectacole pirotehnice şi focuri de artificii” cu articole pirotehnice de divertisment de destinaţie profesională"
source_url: "https://actpermisiv.gov.md/#/ep/permit/61"
retrieved_at: "2026-09-25T22:04:06.307852+00:00"
content_sha256: "de12e26364dd4ad00d9c18c64291fe9d5d3e18decd774ca3a2410d1ed8819062"
language: "ro"
category: "services"
document_type: "json"
document_date: null
effective_from: null
effective_to: null
---

# 83 Licenţă pentru producerea, asamblarea, importul, exportul, reexportul, depozitarea, comercializarea articolelor pirotehnice şi/sau prestarea serviciului „Spectacole pirotehnice şi focuri de artificii” cu articole pirotehnice de divertisment de destinaţie profesională

Act permisiv, emis în condițiile legii de autoritatea competentă, prin care se atestă dreptul laproducerea, asamblarea, importul, exportul, reexportul, depozitarea, comercializarea articolelor pirotehnice şi/sau prestarea serviciului „Spectacole pirotehnice şi focuri de artificii” cu articole pirotehnice de divertisment de destinaţie profesională

## Autoritatea emitentă

Agenția Servicii Publice

## Documente însoțitoare

### Eliberare

- Copia diplomei de studii în domeniul pirotehniei (pentru producerea şi asamblarea articolelor pirotehnice);
- Copia de pe procesul-verbal de control pentru spațiile de depozitare a articolelor pirotehnice, eliberat de organul supravegherii de stat a măsurilor contra incendiilor;
- Copia de pe procesul— verbal de control pentru spaţiile de producere, asamblare, depozitare şi/sau comercializare a articolelor pirotehnice, eliberat de organul supravegherii de stat a măsurilor contra incendiilor.
- Copia de pe carnetul de pirotehnician autorizat pentru cel puţin un angajat;
- Copia certificatului de acreditare a laboratorului de încercări ale articolelor pirotehnice sau de pe contractul de prestare a serviciilor încheiat cu un laborator de încercări acreditat (pentru producerea şi asamblarea articolelor pirotehnice);
### Prelungire

- Copia diplomei de studii în domeniul pirotehniei (pentru producerea şi asamblarea articolelor pirotehnice);
- Copia de pe procesul-verbal de control pentru spațiile de depozitare a articolelor pirotehnice, eliberat de organul supravegherii de stat a măsurilor contra incendiilor;
- Copia de pe procesul— verbal de control pentru spaţiile de producere, asamblare, depozitare şi/sau comercializare a articolelor pirotehnice, eliberat de organul supravegherii de stat a măsurilor contra incendiilor.
- Copia de pe carnetul de pirotehnician autorizat pentru cel puţin un angajat;
- Copia certificatului de acreditare a laboratorului de încercări ale articolelor pirotehnice sau de pe contractul de prestare a serviciilor încheiat cu un laborator de încercări acreditat (pentru producerea şi asamblarea articolelor pirotehnice);
### Reperfectare

- Documentele ce confirmă modificările
- Copia de pe procesul-verbal de control pentru spaţiile de producere, asamblare, depozitare şi/sau comercializare a articolelor pirotehnice, eliberat de organul supravegherii de stat a măsurilor contra incendiilor;
- Copia de pe procesul-verbal de control pentru spațiile de depozitare a articolelor pirotehnice, eliberat de organul supravegherii de stat a măsurilor contra incendiilor;
- Carnetul de pirotehnician autorizat pentru cel puţin un angajat, eliberat de Ministerul Afacerilor Interne

## Cadrul legal

- [Legea Nr. 143 din  17.07.2014 privind regimul articolelor pirotehnice](http://lex.justice.md/index.php?action=view&view=doc&lang=1&id=355607)
- [Legea Nr. 160 din  22.07.2011 privind reglementarea prin autorizare a activităţii de întreprinzător](http://lex.justice.md/md/340497/)
- [Legea Nr. 845 din  03.01.1992 cu privire la antreprenoriat şi întreprinderi](http://lex.justice.md/viewdoc.php?action=view&view=doc&id=311735&lang=1)

## Procesul de eliberare

1. Solicitantul (sau reprezentantul său legal) intră în sistem (Portalul electronic al serviciilor publice) personal sau cu ajutorul recepționarului de la  ghișeu.

2. Solicitantul (sau reprezentantul său legal) îndeplinește cererea și încarcă documentele necesare, personal sau cu ajutorul recepționarului de la ghișeu.

3. În cazul când Solicitantul (sau reprezentantul său legal): a) depune cererea și documentele necesare cu ajutorul recepționarului de la ghișeu, recepționarul:
- va primi și va înregistra corespunzător cererea (declaraţia) pentru obținerea licenţei și va primi documentele prezentate de solicitant, și
- va elibera imediat și necondiționat solicitantului certificatul constatator conform modelului indicat în anexa nr.3 la Legea 160 din 22.07.2011, și
- va expedia cazul (copiile electronice ale cererii și a documentelor prezentate) autorității emitente pentru revizuire.

Cererea poate fi returnată solicitantului doar în cazul când cererea nu conține informația necesară pentru identificarea solicitantului. b) depune cererea și încarcă documentele personal direct în sistem, sistemul:
- va genera automat documentul în format electronic de confirmare a primirii cererii și documentelor („certificatul constatator”) și
- în mod automat va direcționa cererea și setul de documente autorității emitente (șefului direcției).

4. Autoritatea emitentă (șeful direcției) remite cererea și setul de documente specialistului din direcție pentru executare.

5. Specialistul deschide cazul, examinează cererea și documentele însoțitoare, verifică  respectarea condițiilor. În cazul constatării lipsei documentelor /informației necesare prevăzute expres de legislație,   specialistul va sista termenul de examinare a cererii și va informa imediat despre acest fapt solicitantul cu specificarea și descrierea temeiului suspendării, termenului și acțiunilor de remediere pentru a iniția examinarea cererii.

6. În baza setului complet de documente specialistul examinează cazul și organizează examinările suplimentare pe interior pentru luarea deciziei de eliberare a licenței și scrie proiectul deciziei de eliberare a Licenței, care este aprobată si semnată (sau respinsă) de șeful direcției.

7. Dacă eliberarea actului permisiv este acceptată, solicitantul (sau reprezentantul său legal) primește o notificare electronică și achită taxa stabilită prin serviciul M-pay sau la bancă. În cazul în care taxa se achită la bancă, solicitantul prezintă bonul de plată în original cu semnătură/ștampilă umedă.

8. În cazul refuzului cererii specialistul informează solicitantul despre refuz, cu o justificare corespunzătoare în temeiul prevederilor legii, și doar în cazul în care solicitantul nu întrunește condițiile expres specificate în lege sau, după caz, nu demonstrează întrunirea acestor condiții în decursul suspendării termenului de examinare a solicitării.

9. După prezentarea documentului care confirmă achitarea taxei pentru eliberarea/prelungirea sau reperfectarea licenței specialistul perfectează actul permisiv care va fi semnat de conducătorul autorității de licențiere sau de adjunctul acestuia.

10. Când actul permisiv este gata, solicitantul (sau reprezentantul său legal) primește o  notificare electronică, descarcă actul permisiv și confirmă recepționarea documentului.

11. În cazul când actul permisiv se eliberează pe hârtie (la solicitare sau conform cerințelor autorității emitente), recepționarul/specialistul tipărește  actul permisiv, îl livrează solicitantului  (sau reprezentantului său legal) și confirmă recepționarea.

## Perioada de valabilitate

Nelimitat

## Taxa

Eliberarea sau Prelungirea licenței - 3 250 MDL; Reperfectarea licenței și/sau eliberarea copiei de pe aceasta, inclusiv în cazul creării unei noi subdiviziuni (filiale) separate - 325 MDL; Eliberarea licenței solicitanților înregistrați cu cel mult un an înainte de depunerea decarației – 1625 MDL (50%); Duplicatul licenței   – 585 MDL.

## Durata de prestare

Eliberare / Prelungire - 10 zile lucrătoare din data înregistrării declarației
Reperfectare - 5 zile lucrătoare din data înregistrării cererii
