---
document_id: "doc_4e6993d999cb56c3044c"
version_id: "ver_4e6993d9_38ebea44b3bf"
title: "1780401326_plan-ca-dgets_ewYRrh.xlsx"
source_url: "https://chisinauedu.dgets.md/storage/orders/attachments/1780401326_plan-ca-dgets_ewYRrh.xlsx"
retrieved_at: "2026-09-26T07:13:50.942488+00:00"
content_sha256: "38ebea44b3bfcc69011f6d3ef24a7d8154ab104c7494798f7b38f33661968f2c"
language: "ro"
category: "education"
document_type: "xlsx"
document_date: null
effective_from: null
effective_to: null
---

<!-- page: 1 -->

| Planul de admitere aprobat la Consiliul de administrație al OLSDÎ, sesiunea 2026, Anexa nr.2 din Metodologia de admitere a elevilor în învățământul liceal    |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------|

|    | Instituția  de învățământ    | Nr. de clase ai treptei gimnaziale   | Nr. de elevi absolvenți ai treptei gimnaziale   | Nota minimă de concurs stabilită prin decizia Consiliului profesoral   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   | Planificat pentru deschiderea claselor a X-a în  sesiunea de admitere 2026, anul de studii 2026-2027   |
|----|------------------------------|--------------------------------------|-------------------------------------------------|------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|
|    | Instituția  de învățământ    | Nr. de clase ai treptei gimnaziale   | Nr. de elevi absolvenți ai treptei gimnaziale   | Nota minimă de concurs stabilită prin decizia Consiliului profesoral   | Profil real                                                                                            | Profil real                                                                                            | Profil umanist                                                                                         | Profil umanist                                                                                         | Profil general                                                                                         | Profil general                                                                                         | Profil arte                                                                                            | Profil arte                                                                                            | Profil sport                                                                                           | Profil sport                                                                                           | Clase bilingve                                                                                         | Clase bilingve                                                                                         |
|    | Instituția  de învățământ    | Nr. de clase ai treptei gimnaziale   | Nr. de elevi absolvenți ai treptei gimnaziale   | Nota minimă de concurs stabilită prin decizia Consiliului profesoral   | Nr. de clase                                                                                           | Nr. elevi                                                                                              | Nr. de clase                                                                                           | Nr. elevi                                                                                              | Nr. de clase                                                                                           | Nr. elevi                                                                                              | Nr. de clase                                                                                           | Nr. elevi                                                                                              | Nr. de clase                                                                                           | Nr. elevi                                                                                              | Nr. de clase                                                                                           | Nr. elevi                                                                                              |

|   1 | IPLT „Gaudeamus”                            |   4 |   190 | 7.5   |   2 |   30 |   2 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|-----|---------------------------------------------|-----|-------|-------|-----|------|-----|------|-----|-----|-----|-----|-----|-----|-----|-----|
|   2 | IPLTPA „M. Berezovschi”                     |   3 |   240 | 7     |   1 |   36 |   1 |   36 |   0 |   0 |   1 |  36 |   0 |   0 |   0 |   0 |
|   3 | IPLT „Spiru Haret"                          |   4 |   180 | 8.5   |   2 |   54 |   2 |   54 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|   4 | IPLT „Liviu Deleanu”                        |   2 |   171 | 7     |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|   5 | IPLT „Nicolae Iorga”                        |   2 |   190 | 7.5   |   1 |   36 |   1 |   34 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|   6 | IPLT „Hyperion”                             |   2 |   153 | 8     |   1 |   25 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|   7 | IPLT „Mihai Viteazul”                       |   3 |   205 | 8.4   |   1 |   32 |   2 |   56 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|   8 | IPLT ,,Principesa N. Dadiani”               |   2 |   141 | 7.5   |   1 |   32 |   1 |   32 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|   9 | IPLT „Ion Creangă”                          |   3 |   140 | 8     |   2 |   56 |   1 |   28 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  10 | IPLTPA „N. Sulac”                           |   3 |   167 | 7     |   1 |   25 |   2 |   60 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  11 | IPLTPA „Ion și Doina Aldea-Teodorovici”     |   3 |   129 | 7.3   |   1 |   25 |   1 |   28 |   0 |   0 |   1 |  25 |   0 |   0 |   0 |   0 |
|  12 | IPLT „Ginta Latină”                         |   2 |   153 | 7.5   |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  13 | IPLT „Gheorghe Asachi”                      |   4 |   138 | 7.5   |   1 |   35 |   2 |   60 |   0 |   0 |   0 |   0 |   0 |   0 |   1 |  35 |
|  14 | IPLT „Petru Rareș”                          |   2 |   113 | 7     |   1 |   30 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  15 | LT „George Călinescu”                       |   2 |   135 | 7     |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  16 | LT „Mihail Sadoveanu”                       |   2 |   115 | 7.5   |   1 |   28 |   1 |   28 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  17 | IPLT„Petru Zadnipru”                        |   2 |   148 | 7.5   |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  18 | IPLT „Dimitrie Cantemir”                    |   3 |   123 | 7.5   |   2 |   50 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  19 | IPLT „Alexandru cel Bun”                    |   2 |   139 | 6.5   |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  20 | IPLT „Alexandr Pușkin”                      |   3 |   131 | 7.2   |   1 |   30 |   2 |   60 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  21 | IPLT „Onisifor Ghibu”                       |   2 |   129 | 8     |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  22 | LT „N. Gogol”                               |   4 |   143 | 7.5   |   2 |   56 |   2 |   56 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  23 | IPLT „Traian”                               |   2 |   123 | 6     |   1 |   26 |   1 |   28 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  24 | IPLT „Mihai Eminescu”                       |   3 |   132 | 7.5   |   2 |   60 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  25 | LT „George Meniuc”                          |   2 |   102 | 6     |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  26 | IPLT „Alexandru Ioan Cuza”                  |   2 |   109 | 7     |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  27 | IPLT „Petru Movilă”                         |   3 |   102 | 6     |   1 |   25 |   2 |   50 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  28 | IPLT „Mircea Eliade”                        |   2 |   107 | 8.5   |   1 |   36 |   1 |   36 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  29 | LT „Dante Alighieri”                        |   2 |   140 | 7.8   |   1 |   28 |   1 |   28 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  30 | IPLT „OLIMP”                                |   2 |   121 | 6.5   |   1 |   35 |   1 |   35 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  31 | IPLTPA „Mihai Grecu”                        |   3 |   113 | 6     |   1 |   20 |   1 |   20 |   0 |   0 |   1 |  20 |   0 |   0 |   0 |   0 |
|  32 | IPLT „C. Negruzzi”                          |   2 |    89 | 7     |   0 |    0 |   2 |   36 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  33 | IPÎ LT „Orizont”, Durlești                  |   6 |   107 | 7.5   |   4 |   96 |   2 |   48 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  34 | IPLT „M.Kogălniceanu”                       |   2 |   102 | 8     |   1 |   35 |   1 |   35 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  35 | LT „Iulia Hasdeu”                           |   2 |   132 | 7     |   1 |   36 |   1 |   36 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  36 | LT „Miguel de Cervantes Saavedra”           |   2 |   104 | 7     |   1 |   35 |   1 |   35 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  37 | LCI Prometeu-Prim                           |   2 |    80 | 7.5   |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  38 | LTPS „Gloria”                               |   2 |   100 | 6     |   0 |    0 |   0 |    0 |   0 |   0 |   0 |   0 |   2 |  50 |   0 |   0 |
|  39 | IPLT „Nicolae Bălcescu”                     |   2 |    98 | 6     |   1 |   22 |   1 |   22 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  40 | IPLT „Toader Bubuiog”                       |   2 |   118 | 6.5   |   0 |    0 |   2 |   40 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  41 | LTPA „Elena Alistar”                        |   3 |    94 | 7.5   |   1 |   25 |   1 |   25 |   0 |   0 |   1 |  25 |   0 |   0 |   0 |   0 |
|  42 | LT „Pro Succes”                             |   2 |    63 | 7     |   0 |    0 |   2 |   50 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  43 | IPLT „Grigore Vieru”                        |   2 |   102 | 6     |   1 |   18 |   1 |   18 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  44 | LT „Lucian Blaga”                           |   2 |    85 | 6.5   |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  45 | IPLT „A.Mateevici”                          |   2 |    58 | 6     |   1 |   18 |   1 |   18 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  46 | IPLT „Dragoș Vodă”                          |   2 |    95 | 6     |   0 |    0 |   2 |   36 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  47 | IPLT „Universul”                            |   2 |    84 | 6     |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  48 | Liceul Teoretic „Alecu Russo”               |   2 |    95 | 6     |   0 |    0 |   2 |   50 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  49 | IPLT „Liviu Rebreanu”                       |   2 |    93 | 6.5   |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  50 | LT „Antioh Cantemir"                        |   3 |    72 | 6     |   1 |   25 |   2 |   50 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  51 | LT „Academician C. Sibirschi”               |   2 |    79 | 6.4   |   1 |   28 |   1 |   28 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  52 | IP LTPS nr.2                                |   2 |    77 | 6     |   0 |    0 |   0 |    0 |   0 |   0 |   0 |   0 |   2 |  40 |   0 |   0 |
|  53 | LCI „Prometeu-Protalent”                    |   2 |    72 | 8.5   |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  54 | IPÎ LT „Orizont", fil. Ciocana, fil .Lumina |   8 |    80 | 7.5   |   2 |   48 |   2 |   48 |   0 |   0 |   0 |   0 |   0 |   0 |   4 |  96 |
|  55 | IP LT „N. Milescu Spătarul"                 |   2 |    83 | 6     |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  56 | LT „Bogdan Petriceicu Hașdeu”               |   2 |    65 | 6     |   0 |    0 |   2 |   44 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  57 | LT ,,Mihai Marinciuc”                       |   2 |    54 | 7     |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  58 | IPLT "Minerva"                              |   2 |    58 | 6     |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  59 | LT „Mircea cel Bătrân”                      |   2 |    47 | 6     |   0 |    0 |   2 |   40 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  60 | IP LT Waldorf                               |   2 |    67 | 7.5   |   1 |   26 |   1 |   26 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  61 | LT „Vasile Alecsandri”                      |   3 |    87 | 7     |   1 |   25 |   2 |   50 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  62 | LT „Natalia Gheorghiu”                      |   2 |    54 | 6     |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  63 | IPLT ORT „B.Z. Herțli”                      |   2 |    82 | 7     |   1 |   20 |   1 |   20 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  64 | CE Liceu-grădiniță „Kiril și Metodii”       |   2 |    65 | 6     |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  65 | Liceul cu Profil Sportiv Buiucani           |   2 |    80 | 7     |   0 |    0 |   0 |    0 |   0 |   0 |   0 |   0 |   2 |  60 |   0 |   0 |
|  66 | IPLT „Budești”                              |   2 |    53 | 6.5   |   0 |    0 |   2 |   44 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  67 | IPLT „Ștefan cel Mare”                      |   2 |    96 | 7.5   |   1 |   30 |   1 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  68 | IPLT „Tudor Vladimirescu”                   |   2 |    60 | 6     |   0 |    0 |   2 |   50 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  69 | LT „Vasile Lupu"                            |   2 |    58 | 6     |   0 |      |   2 |   50 |   0 |   0 |   0 |     |   0 |     |   0 |     |
|  70 | Instituția Privată Liceul „Da Vinci”        |   2 |    48 | 8.25  |   1 |   24 |   1 |   24 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  71 | IP Liceul „Columna”                         |   2 |    42 | 7     |   1 |   24 |   1 |   24 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  72 | IPLT "Anton Cehov"                          |   2 |    78 | 6     |   1 |   20 |   1 |   20 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  73 | IPLT „Academia Copiilor”                    |   2 |    56 | 6.5   |   0 |    0 |   2 |   44 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  74 | IPLT„Matei Basarab”                         |   2 |    52 | 6     |   1 |   20 |   1 |   20 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  75 | LT ,,I.S.Neciui-Levițchi”                   |   2 |    70 | 6     |   0 |    0 |   2 |   50 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  76 | LT „Titu Maiorescu”                         |   2 |    36 | 6     |   0 |    0 |   2 |   36 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  77 | LT „Mihail Lomonosov”                       |   2 |    25 | 6     |   0 |    0 |   2 |   40 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  78 | IPLT „Rambam”                               |   2 |    38 | 6.5   |   0 |    0 |   2 |   50 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  79 | LT ,,Gheorghe Ghimpu”                       |   2 |    65 | 6, 00 |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  80 | IPLT „Vasile Vasilache"                     |   2 |    51 | 7     |   1 |   25 |   1 |   25 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  81 | IPLT „M. Koțiubinski”                       |   2 |    29 | 6     |   0 |    0 |   2 |   50 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  82 | IÎ Liceul „Litterarum”                      |   2 |    28 | 8     |   1 |   18 |   1 |   18 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  83 | LT „Ștefan Vodă”                            |   2 |    64 | 6     |   0 |    0 |   2 |   44 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  84 | LLMTI Socrate                               |   2 |    21 | 7.5   |   1 |   15 |   1 |   15 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  85 | IPLPA „Iurie Harmelin”                      |   2 |    35 | 6.75  |   0 |    0 |   0 |    0 |   0 |   0 |   2 |  40 |   0 |   0 |   0 |   0 |
|  86 | IP „Liceul de Limbi Moderne și Management”  |   2 |    33 | 7.5   |   1 |   20 |   1 |   20 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  87 | IPLT „Grătiești”                            |   2 |    40 | 6     |   0 |    0 |   2 |   40 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  88 | IP Liceul Moldo-Finlandez                   |   2 |    22 | 7     |   1 |   21 |   1 |   21 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  89 | LT„Vasil Levski”                            |   2 |    31 | 6     |   0 |    0 |   2 |   48 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  90 | IÎ Liceul Teoretic „Evrica"                 |   2 |    10 | 6.5   |   1 |   10 |   1 |   10 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  91 | IÎP Liceul „Svetoci”                        |   2 |    13 | 6     |   1 |   15 |   1 |   15 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  92 | IPIÎ ”EXCELSIS”                             |   2 |    10 | 6.5   |   1 |   10 |   1 |   10 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  93 | IÎPL „ELITEX”                               |   2 |     7 | 7     |   1 |   16 |   1 |   16 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  94 | LT pentru Copii cu Deficiențe de Vedere     |   2 |     8 | 6     |   1 |    5 |   1 |    5 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  95 | LT European                                 |   3 |     0 | 6     |   1 |   15 |   2 |   30 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  96 | IPLT cu Frecvență Redusă nr.1               |   4 |     0 | 5     |   1 |   18 |   3 |   18 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  97 | IPLT cu Frecvență Redusă nr.2               |   3 |     0 | 5     |   0 |    0 |   3 |  105 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|  98 | LT „Dacia”                                  |   2 |    71 | 6     |   1 |   20 |   1 |   20 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |   0 |
|     | 98                                          | 231 |  8493 |       |  84 | 2118 | 130 | 3141 |   0 |   0 |   6 | 146 |   6 | 150 |   5 | 131 |

<!-- page: 2 -->
