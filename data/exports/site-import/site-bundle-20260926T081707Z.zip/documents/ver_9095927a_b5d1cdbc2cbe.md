---
document_id: "doc_9095927afe15535d9fde"
version_id: "ver_9095927a_b5d1cdbc2cbe"
title: "62 (a) Autorizație de import al medicamentelor înregistrate, materiei prime medicamentoase, al materialelor, al articolelor, al ambalajului primar şi secundar utilizate la prepararea şi producerea medicamentelor"
source_url: "https://actpermisiv.gov.md/#/ep/permit/177"
retrieved_at: "2026-09-25T22:04:44.365241+00:00"
content_sha256: "b5d1cdbc2cbe36f15c1f68dc58db8cf8baa547a54b047322a8041bbb312fa380"
language: "ro"
category: "services"
document_type: "json"
document_date: null
effective_from: null
effective_to: null
---

# 62 (a) Autorizație de import al medicamentelor înregistrate, materiei prime medicamentoase, al materialelor, al articolelor, al ambalajului primar şi secundar utilizate la prepararea şi producerea medicamentelor

Permisiunea pentru efectuarea tranzacțiilor de comerț exterior (import) pe o anumită perioadă de timp și în limitele indicate în autorizație.

## Autoritatea emitentă

Agenția Medicamentului și Dispozitivelor Medicale (AMDM)

## Documente însoțitoare

### Eliberare

- Specificaţia tehnică şi de preţ a obiectelor importului scanată
- Specificaţia tehnică şi de preţ a obiectelor importului  în varianta Excel
- Copia contractului de vânzare-cumpărare încheiat cu partenerul de peste hotare
- Argumente

## Cadrul legal

- [HG nr. nr. 920 din 30.08.2005 Cu privire la Nomenclatorul autorizațiilor, permisiunilor și certificatelor, eliberate de autoritățile administrative centrale și organele subordonate acestora persoanelor fizice și juridice pentru practicarea activității ant](http://lex.justice.md/viewdoc.php?action=view&view=doc&id=305510&lang=1)
- [Legea nr. 1456-XII din 25 mai 1993 cu privire la activitatea farmaceutică](http://lex.justice.md/index.php?action=view&view=doc&id=313276)
- [Legea Nr. 160 din  22.07.2011 privind reglementarea prin autorizare a activităţii de întreprinzător](http://lex.justice.md/md/340497/)
- [Legea Nr.1409 din 17.12.1997 cu privire la medicamente](http://lex.justice.md/viewdoc.php?action=view&view=doc&id=311586&lang=1)
- [Ordinul Agenţiei Medicamentului Nr. 1 din 16.01.2006 "Cu privire la autorizarea importului - exportului de medicamente, alte produse farmaceutice şi parafarmaceutice"](http://amed.md/sites/default/files/Autorizarea%20medicamentelor/Autorizare%20de%20import-export/Ordin%20AM%20nr_1_2006_Autorizare%20import.pdf)
- [Ordinul MS AMDM Nr. 5 din 14.01.2011 Privind modificarea și completarea ordinului Agenției Medicamentului nr. 1 din 16.01.2006 Cu privire la autorizarea importului-exportului de medicamente, alte produse farmaceutice și parafarmaceutice](http://amed.md/sites/default/files/Autorizarea%20me dicamentelor/Autorizare%20de%20importexport/Ordin%2 0AM%20nr_%205_Privind%20modificarea_completarea%20or dinului%20nr1din160106.pdf)
- [Ordinul MS nr.559 din 29.06.2017 Cu privire la Regulamentul privind autorizarea importului medicamentelor, altor produse farmaceutice, parafarmaceutice și materiei prime medicamentoase neautorizate în Republica Moldova](http://amed.md/sites/default/files/Medicamente/Ordin%20MS%20nr.%20559%20din%2029.06.2017.pdf)

## Procesul de eliberare

1. Solicitantul sau reprezentantul său legal (în continuare Solicitant) întră în sistem (Portalul electronic al serviciilor publice) personal sau cu ajutorul recepţionarului de la ghişeul unic.

2. Solicitantul îndeplineşte cererea şi încarcă documentele necesare specificate în sistem, personal sau cu ajutorul recepţionarului de la ghişeul unic: În cazul când Solicitantul (sau reprezentantul său legal): a) depune cererea și documentele necesare cu ajutorul recepționarului de la ghișeu, recepționarul: -	va primi și va înregistra corespunzător cererea de solicitare a autorizației și va primi documentele prezentate de solicitant -	va elibera imediat și necondiționat solicitantului certificatul constatator conform modelului indicat în anexa nr.3 la Legea 160 din 22.07.2011, și -	va expedia cazul subdiviziunii emitente pentru revizuire. Cererea poate fi returnată solicitantului doar în cazul când cererea nu conține informația necesară pentru identificarea solicitantului. b) depune cererea și încarcă documentele personal direct în sistem, sistemul: -	va genera automat documentul în format electronic de confirmare a primirii cererii și documentelor („certificatul constatator”) și în mod automat va direcționa cererea și setul de documente autorității emitente.

3. Autoritatea emitentă (registratorul) deschide cazul, verifică cererea și documentele depuse pentru înregistrare în vederea corespunderii acestora cerințelor stabilite de lege. În cazul constatării lipsei documentelor/informației necesare prevăzute expres de legislație, autoritatea emitentă (registratorul) va respinge cererea și va informa imediat despre acest fapt solicitantul cu specificarea și descrierea temeiului suspendării, precum și acțiunilor de remediere pentru a iniția examinarea cererii.

4. Specialistul perfectează actul permisiv sau scrie o scrisoare de respingere, cu o justificare corespunzătoare în temeiul prevederilor legii, cu înştiinţarea directă a solicitantului, care se va examina şi semna de directorul autorităţii emitente.

5. Când actul permisiv (scrisoarea) este gata, solicitantul (sau reprezentantul său legal) primeşte o  notificare electronică, descarcă actul permisiv şi confirmă recepţionarea documentului.

6. În cazul când actul permisiv se eliberează pe hârtie (la solicitare sau conform cerinţelor autorităţii emitente), recepţionarul tipăreşte  actul permisiv, îl înmînă solicitantului  (sau reprezentantului său legal), care confirmă recepţionarea.

## Perioada de valabilitate

- pentru autorizarea importului al medicamentelor înregistrate, materiei prime medicamentoase, al materialelor, al articolelor, al ambalajului primar şi secundar utilizate la prepararea şi producerea medicamentelor - până la 1 an

## Taxa

Gratuit

## Durata de prestare

- pentru autorizarea importului al medicamentelor înregistrate, materiei prime medicamentoase, al materialelor, al articolelor, al ambalajului primar şi secundar utilizate la prepararea şi producerea medicamentelor -10 zile lucrătoare de la data depunerii cererii
